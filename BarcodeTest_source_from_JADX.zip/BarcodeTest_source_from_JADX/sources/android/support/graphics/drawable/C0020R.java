package android.support.graphics.drawable;

import p004kr.p005co.bluebird.android.BarcodeTest.C0292R;

/* renamed from: android.support.graphics.drawable.R */
public final class C0020R {

    /* renamed from: android.support.graphics.drawable.R$attr */
    public static final class attr {
        public static final int font = 2130837615;
        public static final int fontProviderAuthority = 2130837617;
        public static final int fontProviderCerts = 2130837618;
        public static final int fontProviderFetchStrategy = 2130837619;
        public static final int fontProviderFetchTimeout = 2130837620;
        public static final int fontProviderPackage = 2130837621;
        public static final int fontProviderQuery = 2130837622;
        public static final int fontStyle = 2130837623;
        public static final int fontWeight = 2130837624;
    }

    /* renamed from: android.support.graphics.drawable.R$bool */
    public static final class bool {
        public static final int abc_action_bar_embed_tabs = 2130903040;
    }

    /* renamed from: android.support.graphics.drawable.R$color */
    public static final class color {
        public static final int notification_action_color_filter = 2130968638;
        public static final int notification_icon_bg_color = 2130968639;
        public static final int ripple_material_light = 2130968668;
        public static final int secondary_text_default_material_light = 2130968670;
    }

    /* renamed from: android.support.graphics.drawable.R$dimen */
    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 2131034188;
        public static final int compat_button_inset_vertical_material = 2131034189;
        public static final int compat_button_padding_horizontal_material = 2131034190;
        public static final int compat_button_padding_vertical_material = 2131034191;
        public static final int compat_control_corner_material = 2131034192;
        public static final int notification_action_icon_size = 2131034202;
        public static final int notification_action_text_size = 2131034203;
        public static final int notification_big_circle_margin = 2131034204;
        public static final int notification_content_margin_start = 2131034205;
        public static final int notification_large_icon_height = 2131034206;
        public static final int notification_large_icon_width = 2131034207;
        public static final int notification_main_column_padding_top = 2131034208;
        public static final int notification_media_narrow_margin = 2131034209;
        public static final int notification_right_icon_size = 2131034210;
        public static final int notification_right_side_padding_top = 2131034211;
        public static final int notification_small_icon_background_padding = 2131034212;
        public static final int notification_small_icon_size_as_large = 2131034213;
        public static final int notification_subtext_size = 2131034214;
        public static final int notification_top_pad = 2131034215;
        public static final int notification_top_pad_large_text = 2131034216;
    }

    /* renamed from: android.support.graphics.drawable.R$drawable */
    public static final class C0021drawable {
        public static final int notification_action_background = 2131099732;
        public static final int notification_bg = 2131099733;
        public static final int notification_bg_low = 2131099734;
        public static final int notification_bg_low_normal = 2131099735;
        public static final int notification_bg_low_pressed = 2131099736;
        public static final int notification_bg_normal = 2131099737;
        public static final int notification_bg_normal_pressed = 2131099738;
        public static final int notification_icon_background = 2131099739;
        public static final int notification_template_icon_bg = 2131099740;
        public static final int notification_template_icon_low_bg = 2131099741;
        public static final int notification_tile_bg = 2131099742;
        public static final int notify_panel_notification_icon_bg = 2131099743;
    }

    /* renamed from: android.support.graphics.drawable.R$id */
    public static final class C0022id {
        public static final int action_container = 2131165198;
        public static final int action_divider = 2131165200;
        public static final int action_image = 2131165201;
        public static final int action_text = 2131165208;
        public static final int actions = 2131165209;
        public static final int async = 2131165214;
        public static final int blocking = 2131165217;
        public static final int chronometer = 2131165229;
        public static final int forever = 2131165245;
        public static final int icon = 2131165248;
        public static final int icon_group = 2131165249;
        public static final int info = 2131165252;
        public static final int italic = 2131165253;
        public static final int line1 = 2131165255;
        public static final int line3 = 2131165256;
        public static final int normal = 2131165265;
        public static final int notification_background = 2131165266;
        public static final int notification_main_column = 2131165267;
        public static final int notification_main_column_container = 2131165268;
        public static final int right_icon = 2131165278;
        public static final int right_side = 2131165279;
        public static final int text = 2131165312;
        public static final int text2 = 2131165313;
        public static final int time = 2131165316;
        public static final int title = 2131165317;
    }

    /* renamed from: android.support.graphics.drawable.R$integer */
    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 2131230724;
    }

    /* renamed from: android.support.graphics.drawable.R$layout */
    public static final class layout {
        public static final int notification_action = 2131296284;
        public static final int notification_action_tombstone = 2131296285;
        public static final int notification_template_custom_big = 2131296292;
        public static final int notification_template_icon_group = 2131296293;
        public static final int notification_template_part_chronometer = 2131296297;
        public static final int notification_template_part_time = 2131296298;
    }

    /* renamed from: android.support.graphics.drawable.R$string */
    public static final class string {
        public static final int status_bar_notification_info_overflow = 2131492899;
    }

    /* renamed from: android.support.graphics.drawable.R$style */
    public static final class style {
        public static final int TextAppearance_Compat_Notification = 2131558650;
        public static final int TextAppearance_Compat_Notification_Info = 2131558651;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131558653;
        public static final int TextAppearance_Compat_Notification_Time = 2131558656;
        public static final int TextAppearance_Compat_Notification_Title = 2131558658;
        public static final int Widget_Compat_NotificationActionContainer = 2131558763;
        public static final int Widget_Compat_NotificationActionText = 2131558764;
    }

    /* renamed from: android.support.graphics.drawable.R$styleable */
    public static final class styleable {
        public static final int[] FontFamily = {C0292R.attr.fontProviderAuthority, C0292R.attr.fontProviderCerts, C0292R.attr.fontProviderFetchStrategy, C0292R.attr.fontProviderFetchTimeout, C0292R.attr.fontProviderPackage, C0292R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = {C0292R.attr.font, C0292R.attr.fontStyle, C0292R.attr.fontWeight};
        public static final int FontFamilyFont_font = 0;
        public static final int FontFamilyFont_fontStyle = 1;
        public static final int FontFamilyFont_fontWeight = 2;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
    }
}
